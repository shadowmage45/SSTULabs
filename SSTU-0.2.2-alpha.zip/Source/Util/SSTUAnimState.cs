using System;

namespace SSTUTools
{
	public enum SSTUAnimState
	{
		STOPPED_START,
		STOPPED_END,
		PLAYING_FORWARD,
		PLAYING_BACKWARD,
	}
}

